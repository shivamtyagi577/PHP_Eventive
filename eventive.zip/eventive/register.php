<?php
include "conn.php";

if (isset($_POST["submit"])) {
    $fname = $_POST["fname"];
    $dob = $_POST["dob"];
    $email = $_POST["email"];
    $proof = $_POST["idproof"];
    $contact = $_POST["contact"];
    $event = $_POST["event"];
    $pass = md5($_POST["password"]);
    $conf_pass = md5($_POST["confirm"]);
    

    if ($pass != $conf_pass) {
        echo "<script type=\"text/javascript\">\n";
        echo "  alert(\"Passwords do not match. Try again!\");\n";
        echo "</script>\n\n";
        header("refresh:0;url=register.php");
        exit();
    }

    
    if ((strlen($contact) != 10)) {
        echo "<script type=\"text/javascript\">\n";
        echo "  alert(\"Invalid contact number. Try again!\");\n";
        echo "</script>\n\n";
        header("refresh:0;url=register.php");
        exit();
    }
    
    $bday = new DateTime($dob); // Your date of birth
    $today = new Datetime(date('d.m.y'));
    $diff = $today->diff($bday);
    $age = $diff->y;

    if ($age <= 18) {
        echo "<script type=\"text/javascript\">\n";
        echo "  alert(\"Minimum age to register is 18!\");\n";
        echo "</script>\n\n";
        header("refresh:0;url=register.php");
        exit();
    }

    $chk1 = mysqli_query($conn, "SELECT * FROM login WHERE username = '$email'");
    if ($r1 = mysqli_fetch_assoc($chk1) > 0) {
        echo "<script type=\"text/javascript\">\n";
        echo "  alert(\"E-mail already exits. Try again!\");\n";
        echo "</script>\n\n";
        header("refresh:0;url=register.php");
        exit();
    }


    $q1 = mysqli_query($conn, "INSERT INTO customer (cust_name, cust_age, cust_idproof,cust_eventname, email, phone) VALUES ('$fname','$age', '$proof', '$event','$email','$contact')");   
    

    if ($q1) {
        $q2 = mysqli_query($conn, "INSERT INTO login (username, password, level) VALUES ('$email', '$pass', 1)");
        echo "<script type=\"text/javascript\">\n";
        echo "  alert(\"You are registered successfully! :)\");\n";
        echo "</script>\n\n";
    }
}

?>

<!DOCTYPE html>
<html lang="en"><!-- Basic -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <!-- Site Metas -->
    <title>Eventive- Guest to your occassio...</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/finallogo.png" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/finallogo.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Pogo Slider CSS -->
    <link rel="stylesheet" href="css/pogo-slider.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css"
          href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css">
    <style type="text/css">
        .container {
            margin-top: 40px;
        }

        .btn-primary {
            width: 100%;
        }
    </style>


    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body id="home" data-spy="scroll" data-target="#navbar-wd" data-offset="98">
<form action="register.php" method="post">

    <!-- LOADER -->
    <div id="preloader">
        <div class="preloader pulse">
            <h3>EVENTIVE</h3>
        </div>
    </div><!-- end loader -->
    <!-- END LOADER -->

    <!-- Start header -->
    <header class="top-header">
        <nav class="navbar header-nav navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="index.html"><img src="images/finallogoeventive.png" alt="image"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-wd"
                        aria-controls="navbar-wd" aria-expanded="false" aria-label="Toggle navigation">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbar-wd">
                    <ul class="navbar-nav">
                        <li><a class="nav-link" href="index.php">Home</a></li>
                        <!--                        <li><a class="nav-link" href="#">About Us</a></li>-->
                        <!--                        <li><a class="nav-link" href="#">Story</a></li>-->
                        <!--                        <li><a class="nav-link" href="#">Family</a></li>-->
                        <!--                        <li><a class="nav-link" href="#">Gallery</a></li>-->
                        <!--                        <li><a class="nav-link" href="#">Wedding</a></li>-->
                        <!--                        <li><a class="nav-link" href="#">Events</a></li>-->
                        <li><a class="nav-link" href="#">Register</a></li>
<!--                        <li><a class="nav-link" href="LOG/login.html">Login</a></li>-->
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <!-- Start Contact -->
    <div id="contact" class="contact-box">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="title-box">
                        <h2>Register with us!</h2>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="panel panel-primary">
                    <div class="panel-heading">Enter the details!</div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label">Full Name</label>
                                    <input type="text" class="form-control" name="fname" id="fname">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label">Date of birth</label>
                                    <input type="date" class="form-control" name="dob" id="lname">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label" for="email">E-mail ID</label>
                                    <input type="email" class="form-control" name="email" id="email">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label">ID Proof</label>
                                    <input type="text" class="form-control" name="idproof" id="age">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label">Contact</label>
                                    <input type="text" class="form-control" name="contact" id="contact">
                                </div>
                            </div>
                            <div class='col-md-6'>
                                <div class="form-group">
                                    <label class="control-label">Event Type</label>

                                    <input type='text' class="form-control" name="event"/>

                                </div>
                            </div>
                            <div class='col-md-6'>
                                <div class="form-group">
                                    <label class="control-label">Password</label>

                                    <input type='password' class="form-control" name="password"/>

                                </div>
                            </div>
                            <div class='col-md-6'>
                                <div class="form-group">
                                    <label class="control-label">Confirm password</label>

                                    <input type='password' class="form-control" name="confirm"/>

                                </div>
                            </div>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Submit" name="submit">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Contact -->
</form>
<!-- Start Footer -->
<footer class="footer-box">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <p class="footer-company-name">Copyright &copy 2020 All Rights Reserved.</p>
            </div>
        </div>
    </div>
</footer>
<!-- End Footer -->

<!-- ALL JS FILES -->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- ALL PLUGINS -->
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/jquery.pogo-slider.min.js"></script>
<script src="js/slider-index.js"></script>
<script src="js/smoothscroll.js"></script>
<script src="js/responsiveslides.min.js"></script>
<script src="js/timeLine.min.js"></script>
<script src="js/form-validator.min.js"></script>
<script src="js/contact-form-script.js"></script>
<script src="js/custom.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/2.14.1/moment.min.js"></script>
<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<script type='text/javascript'>
    $(document).ready(function () {
        $('#datetimepicker1').datetimepicker();
    });
</script>

</body>
</html>