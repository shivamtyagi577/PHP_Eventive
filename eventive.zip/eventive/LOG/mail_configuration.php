<?php
define("PROJECT_HOME","http://localhost/PG/ATTG/LOG/");

define("PORT", "587"); // port number
//define("PORT", "465"); // port number
define("MAIL_USERNAME", "jayaram.gs@mca.christuniversity.in"); // smtp usernmae
define("MAIL_PASSWORD", "48438025"); // smtp password
define("MAIL_HOST", "smtp.gmail.com"); // smtp host
define("MAILER", "smtp");
define("SENDER_NAME", "ADMIN");
define("SERDER_EMAIL", "jayaram.gs@mca.christuniversity.in");
?>