<?php
// if (!session_start()) {
    session_start();
// }

if(!($_SESSION['user_mail']))
{
 $_SESSION['user_mail'] = "";   
}

include "conn.php";

if (isset($_POST["submit"])) {
    $fname = $_POST["fname"];
    $lname = $_POST["lname"];
    $email = $_POST["email"];
    $age = $_POST["age"];
    $contact = $_POST["contact"];
    $date = $_POST["date"];

// $q1 = mysqli_query($conn, "INSERT INTO ap_timings (ap_date) VALUES ('$date')");

    $q1 = mysqli_query($conn, "INSERT INTO ap_contact (email, phno) VALUES ('$email', '$contact')");

    //$qc = mysqli_query($conn,"Insert into ap_contact ()")
    // $q1 = mysqli_query($conn, "Insert into appointment (ap_firstname,ap_lastname) VALUES ('$fname','$lname')");

    if ($q1) {
        // $v1 = mysqli_query($conn,"SELECT ap_contactkey from ap_contact where ")
        // $q2 = mysqli_query($conn, "INSERT INTO appointment (ap_firstname,ap_firstname, ap_age, )")
        echo "<script type=\"text/javascript\">\n";
        echo "  alert(\"$date\");\n";
        echo "</script>\n\n";
    }
}

?>

<!DOCTYPE html>
<html lang="en"><!-- Basic -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <!-- Site Metas -->
    <title>Eventive- Guest to your occassio...</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/finallogo.png" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/finallogo.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Pogo Slider CSS -->
    <link rel="stylesheet" href="css/pogo-slider.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css"
          href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css">
    <style type="text/css">
        .container {
            margin-top: 40px;
        }

        .btn-primary {
            width: 100%;
        }
    </style>


    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body id="home" data-spy="scroll" data-target="#navbar-wd" data-offset="98">
<form action="index.php" method="post">

    <!-- LOADER -->
    <div id="preloader">
        <div class="preloader pulse">
            <h3>EVENTIVE</h3>
        </div>
    </div><!-- end loader -->
    <!-- END LOADER -->

    <!-- Start header -->
    <header class="top-header">
        <nav class="navbar header-nav navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="index.html"><img src="images/finallogoeventive.png" alt="image"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-wd"
                        aria-controls="navbar-wd" aria-expanded="false" aria-label="Toggle navigation">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbar-wd" style="font-family: acme;">
                    <ul class="navbar-nav">
                        <li><a class="nav-link active" href="#home">Home</a></li>
                        <li><a class="nav-link" href="#about">About Us</a></li>
                        <li><a class="nav-link" href="#story">Story</a></li>
                        <li><a class="nav-link" href="#family">Family</a></li>
                        <li><a class="nav-link" href="#gallery">Gallery</a></li>
                        <li><a class="nav-link" href="#Wedding">Recents</a></li>
                        <li><a class="nav-link" href="#events">Events</a></li>

                        <?php
                        $z1 = mysqli_query($conn,"SELECT * FROM login where username = '$_SESSION[user_mail]'");
                        if(mysqli_num_rows($z1) == 1)
                        {
                            ?>
                                <li><a class="nav-link" href="appointment.php">Appointment</a></li>
                                <li><a class="nav-link" href="logout.php">Logout</a></li>
                            <?php
                        }
                        else
                        {
                            ?>
                                <li><a class="nav-link" href="register.php">Register</a></li>
                                <li><a class="nav-link" href="LOG/login.html">Login</a></li>
                            <?php
                        }
                        ?>

                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- End header -->

    <!-- Start Banner -->
    <div class="home-slider">
        <ul class="rslides">
            <li><img src="images/slider-014.jpg" alt=""></li>
            <li><img src="images/slider-02.jpg" alt=""></li>
            <li><img src="images/slider-03.jpg" alt=""></li>
            <li><img src="images/slider-015.jpg" alt=""></li>
            <li><img src="images/slider-16.jpg" alt=""></li>
        </ul>
        <div class="lbox-details">
            <h1>EVENTIVE</h1>
            <h2>Guest to your occassio...</h2>

        </div>
    </div>
    <!-- End Banner -->

    <!-- Start About us -->
    <div id="about" class="about-box">
        <div class="about-a1">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="title-box">
                            <h2>Eventive Family...</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="row align-items-center about-main-info">
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="about-m">
                                    <div class="about-img">
                                        <img class="img-fluid" src="images/about-img-01.jpg" alt=""/>
                                    </div>
                                    <ul>
                                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-8 col-md-6 col-sm-12">
                                <h2><i class="fa fa-heart-o" aria-hidden="true"></i> <span>Sanjal</span> <i
                                            class="fa fa-heart-o" aria-hidden="true"></i></h2>
                                <p>Some thing about...... </p>
                            </div>
                        </div>
                        <div class="row align-items-center about-main-info">
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="about-m">
                                    <div class="about-img">
                                        <img class="img-fluid" src="images/about-img-02.jpg" alt=""/>
                                    </div>
                                    <ul>
                                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-8 col-md-6 col-sm-12">
                                <h2><i class="fa fa-heart-o" aria-hidden="true"></i> <span>AVinash Gowda </span> <i
                                            class="fa fa-heart-o" aria-hidden="true"></i></h2>
                                <p>Something About </p>
                            </div>
                        </div>
                        <div class="row align-items-center about-main-info">
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="about-m">
                                    <div class="about-img">
                                        <img class="img-fluid" src="images/about-img-02.jpg" alt=""/>
                                    </div>
                                    <ul>
                                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-8 col-md-6 col-sm-12">
                                <h2><i class="fa fa-heart-o" aria-hidden="true"></i> <span>Hema </span> <i
                                            class="fa fa-heart-o" aria-hidden="true"></i></h2>
                                <p>Something About </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End About us -->

    <!-- Start Story -->
    <div id="story" class="story-box main-timeline-box">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="title-box">
                        <h2>Our Story</h2>
                        <p>Eventive reviews </p>
                    </div>
                </div>
            </div>

            <div class="timeLine">
                <div class="row">
                    <div class="lineHeader hidden-sm hidden-xs"></div>
                    <div class="lineFooter hidden-sm hidden-xs"></div>

                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 item">
                        <div class="caption">
                            <div class="star center-block" style="background-color: #6F60c6">
                                <span class="h3">01</span>
                                <span>March </span>
                                <span>2017</span>
                            </div>
                            <div class="image">
                                <img src="images/themef.jpg" alt=""/>
                                <div class="title">
                                    <h2>Birthday <i class="fa fa-angle-right" aria-hidden="true"></i></h2>
                                </div>
                            </div>
                            <div class="textContent">
                                <p class="lead">Customers review on birthday.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 item">
                        <div class="caption">
                            <div class="star center-block">
                                <span class="h3">03</span>
                                <span>April</span>
                                <span>2017</span>
                            </div>
                            <div class="image">
                                <img src="images/awardf.jpg" alt=""/>
                                <div class="title">
                                    <h2> Award Fuctions<i class="fa fa-angle-right" aria-hidden="true"></i></h2>
                                </div>
                            </div>
                            <div class="textContent">
                                <p class="lead">Customers review on Theme Party.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 item">
                        <div class="caption">
                            <div class="star center-block">
                                <span class="h3">03</span>
                                <span>May</span>
                                <span>2017</span>
                            </div>
                            <div class="image">
                                <img src="images/exhibitionf.jpg" alt=""/>
                                <div class="title">
                                    <h2>Exibition <i class="fa fa-angle-right" aria-hidden="true"></i></h2>
                                </div>
                            </div>
                            <div class="textContent">
                                <p class="lead">Customers review on Exibition..</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 item">
                        <div class="caption">
                            <div class="star center-block">
                                <span class="h3">04</span>
                                <span>June</span>
                                <span>2017</span>
                            </div>
                            <div class="image">
                                <img src="images/outingf.jpg" alt=""/>
                                <div class="title">
                                    <h2>Outing <i class="fa fa-angle-right" aria-hidden="true"></i></h2>
                                </div>
                            </div>
                            <div class="textContent">
                                <p class="lead">Customers review on outing.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 item">
                        <div class="caption">
                            <div class="star center-block">
                                <span class="h3">04</span>
                                <span>July</span>
                                <span>2017</span>
                            </div>
                            <div class="image">
                                <img src="images/time-05.jpg" alt=""/>
                                <div class="title">
                                    <h2>My Wedding <i class="fa fa-angle-right" aria-hidden="true"></i></h2>
                                </div>
                            </div>
                            <div class="textContent">
                                <p class="lead">Customers review on Wedding..</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
    <!-- End Story -->

    <!-- Start Family -->
    <div id="family" class="family-box">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="title-box">
                        <h2>Family</h2>
                        <p>Guest to your occassio...</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="single-team-member">
                        <div class="family-img">
                            <img class="img-fluid" src="images/family-01.jpg" alt=""/>
                        </div>
                        <div class="family-info">
                            <h4>Mr. RAHUL </h4>
                            <p>Cheif operational officer</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="single-team-member">
                        <div class="family-img">
                            <img class="img-fluid" src="images/family-02.jpg" alt=""/>
                        </div>
                        <div class="family-info">
                            <h4>ms.Sunaina</h4>
                            <p>Finance</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="single-team-member">
                        <div class="family-img">
                            <img class="img-fluid" src="images/family-03.jpg" alt=""/>
                        </div>
                        <div class="family-info">
                            <h4>Mr. Vignesh Vishwanath </h4>
                            <p>Marketing </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="single-team-member">
                        <div class="family-img">
                            <img class="img-fluid" src="images/family-04.jpg" alt=""/>
                        </div>
                        <div class="family-info">
                            <h4>Ms Svetha Venkataraman </h4>
                            <p>HR</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="single-team-member">
                        <div class="family-img">
                            <img class="img-fluid" src="images/family-05.jpg" alt=""/>
                        </div>
                        <div class="family-info">
                            <h4>Mr Renit Anthony</h4>
                            <p>Operational officer</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="single-team-member">
                        <div class="family-img">
                            <img class="img-fluid" src="images/family-06.jpg" alt=""/>
                        </div>
                        <div class="family-info">
                            <h4>Mr. Shankar S </h4>
                            <p>Cast and Crew</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Family -->

    <!-- Start Gallery -->
    <div id="gallery" class="gallery-box">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="title-box">
                        <h2>Gallery</h2>
                        <p>Guest to your occassio...</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <ul class="popup-gallery clearfix">
                    <li>
                        <a href="images/gallery-01.jpg">
                            <img class="img-fluid" src="images/gallerytheme1.jpg" alt="single image">
                            <span class="overlay"><i class="fa fa-heart-o" aria-hidden="true"></i></span>
                        </a>
                    </li>
                    <li>
                        <a href="images/gallery-02.jpg">
                            <img class="img-fluid" src="images/gallery-02.jpg" alt="single image">
                            <span class="overlay"><i class="fa fa-heart-o" aria-hidden="true"></i></span>
                        </a>
                    </li>
                    <li>
                        <a href="images/gallery-03.jpg">
                            <img class="img-fluid" src="images/galleryout1.jpg" alt="single image">
                            <span class="overlay"><i class="fa fa-heart-o" aria-hidden="true"></i></span>
                        </a>
                    </li>
                    <li>
                        <a href="images/gallery-04.jpg">
                            <img class="img-fluid" src="images/gallery-04.jpg" alt="single image">
                            <span class="overlay"><i class="fa fa-heart-o" aria-hidden="true"></i></span>
                        </a>
                    </li>
                    <li>
                        <a href="images/gallery-05.jpg">
                            <img class="img-fluid" src="images/galleryawards.jpg" alt="single image">
                            <span class="overlay"><i class="fa fa-heart-o" aria-hidden="true"></i></span>
                        </a>
                    </li>
                    <li>
                        <a href="images/gallery-06.jpg">
                            <img class="img-fluid" src="images/gallery-06.jpg" alt="single image">
                            <span class="overlay"><i class="fa fa-heart-o" aria-hidden="true"></i></span>
                        </a>
                    </li>
                    <li>
                        <a href="images/gallery-07.jpg">
                            <img class="img-fluid" src="images/gallerytheme%20(2).jpg" alt="single image">
                            <span class="overlay"><i class="fa fa-heart-o" aria-hidden="true"></i></span>
                        </a>
                    </li>
                    <li>
                        <a href="images/gallery-08.jpg">
                            <img class="img-fluid" src="images/galleryout2.jpg" alt="single image">
                            <span class="overlay"><i class="fa fa-heart-o" aria-hidden="true"></i></span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!-- End Gallery -->

    <!-- Start Wedding -->

    <div id="Wedding" class="Wedding-box">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="title-box">
                        <h2>Current events</h2>
                        <p>Guest to your occassio...</p>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4 col-sm-6">
                    <div class="serviceBox">
                        <div class="service-icon"><i class="flaticon-bachelorette-party"></i></div>
                        <h3 class="title">Theme Party </h3>
                        <h4>04 March 2020 at 7:30 pm</h4>
                        <p class="description">
                            Theme parties are most loved by our customers, The next theme party we are conducting has a
                            whole lot of different theme.
                        </p>
                    </div>
                </div>

                <div class="col-md-4 col-sm-6">
                    <div class="serviceBox">
                        <div class="service-icon"><i class="flaticon-wedding"></i></div>
                        <h3 class="title">Wedding Ceremony </h3>
                        <h4>29 Feb 2020 at 9:30 pm</h4>
                        <p class="description">
                            John and elsa are going to tie there knots, so lots more fun,blessings and entertainment.
                        </p>
                    </div>
                </div>

                <div class="col-md-4 col-sm-6">
                    <div class="serviceBox">
                        <div class="service-icon"><i class="flaticon-reception-bell"></i></div>
                        <h3 class="title">Caterings </h3>
                        <h4>29 Feb 2020 at 9:30 pm</h4>
                        <p class="description">
                            content to be added..
                        </p>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- End Wedding -->

    <!-- Start Events -->
    <div id="events" class="events-box">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="title-box">
                        <h2>Events</h2>
                        <p>Guest to your occassio...</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="event-inner">
                        <div class="event-img">
                            <img class="img-fluid" src="images/event-img-01.jpg" alt=""/>
                        </div>
                        <h2>2 June 2018 Engagement</h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has
                            been the industry's standard </p>
                        <a href="#">See location <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="event-inner">
                        <div class="event-img">
                            <img class="img-fluid" src="images/event-img-02.jpg" alt=""/>
                        </div>
                        <h2>3 June 2018 Main Ceremony </h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has
                            been the industry's standard </p>
                        <a href="#">See location <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="event-inner">
                        <div class="event-img">
                            <img class="img-fluid" src="images/event-img-03.jpg" alt=""/>
                        </div>
                        <h2>4 June 2018 Wedding party </h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has
                            been the industry's standard </p>
                        <a href="#">See location <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Events -->
</form>
<!-- Start Footer -->
<footer class="footer-box">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <p class="footer-company-name">Copyright &copy 2020 All Rights Reserved.</p>
                <!--                    <a href="#">Eventive</a>-->
            </div>
        </div>
    </div>
</footer>
<!-- End Footer -->

<!-- ALL JS FILES -->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- ALL PLUGINS -->
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/jquery.pogo-slider.min.js"></script>
<script src="js/slider-index.js"></script>
<script src="js/smoothscroll.js"></script>
<script src="js/responsiveslides.min.js"></script>
<script src="js/timeLine.min.js"></script>
<script src="js/form-validator.min.js"></script>
<script src="js/contact-form-script.js"></script>
<script src="js/custom.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/2.14.1/moment.min.js"></script>
<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<script type='text/javascript'>
    $(document).ready(function () {
        $('#datetimepicker1').datetimepicker();
    });
</script>

</body>
</html>